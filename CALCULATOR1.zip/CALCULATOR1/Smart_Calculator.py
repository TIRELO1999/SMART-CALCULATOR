"""
__THIS CALCULATOR IS DEVELOPED BY TIRELO GLIFFORD LESUFI.
__YOU ARE NOT ALLOWED TO PUBLISH THIS CODE/APPLICATION WITHOUT A VALID PERMIT FROM TIRELO GLIFFORD LESUFI
__ENJOY THE CODE__
"""


from tkinter import *
import math
import parser
import tkinter.messagebox

import  os
import pyttsx3

def talk(text):
    engine=pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

root=Tk()
root.title("Calculator")
root.configure(bg="khaki")
#root.geometry("480x568+0+0")


calc=Frame(root)
calc.grid()

class Calc():
    def __init__(self):
        self.arithmetic_op=""
        self.result=False
        self.check_sum=False
        self.total=0
        self.current=""
        self.input_value=True


    def Number_Enter(self,num):
        self.result=False
        firstnum=txtDisplay.get()
        secondnum=str(num)
        if self.input_value:
            self.current=secondnum
            self.input_value=False
        else:
            if secondnum=='.':
                if secondnum in firstnum:
                    return
            self.current=firstnum+secondnum
        self.display(self.current)

    def sum_of_total(self):
        try:
            self.result=True
            self.current=float(self.current)
            if self.check_sum ==True:
                self.valid_function()
            else:
                self.total=float(txtDisplay.get())
        except(Exception):
            self.display("Maths Error!!!")

    def valid_function(self):
        if self.arithmetic_op=="add":
            self.total += self.current
        if self.arithmetic_op=="sub":
            self.total -= self.current
        if self.arithmetic_op=="multi":
            self.total *= self.current
        if self.arithmetic_op=="divide":
            self.total /= self.current


        self.input_value=True
        self.check_sum=False
        self.display(self.total)

    def operation(self,arithmetic_op):
        try:
            self.current=float(self.current)
            if self.check_sum:
                self.valid_function()
            elif not self.result:
                self.total=self.current
                self.input_value=True
            self.check_sum=True
            self.arithmetic_op=arithmetic_op
            self.result=False
        except(Exception):
            self.display("Error!!")


    def display(self,value):
        txtDisplay.delete(0,END)
        txtDisplay.insert(0,value)

    def Clear_Entry(self):
        self.result = False
        self.current = ""
        self.display(self.current)
        self.input_value=True

    def Clear_All_Entry(self):
        self.Clear_Entry()
        self.total = ""

    def MathsPM(self):
        try:
            self.result = False
            self.current = -(float(txtDisplay.get()))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Sqaure_Root(self):
        try:
            self.result = False
            self.current = math.sqrt(float(txtDisplay.get()))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Sin(self):
        try:
            self.result = False
            self.current = math.sin(math.radians(float(txtDisplay.get())))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Cos(self):
        try:
            self.result = False
            self.current = math.cos(math.radians(float(txtDisplay.get())))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Tan(self):
        try:
            self.result = False
            self.current = math.tan(math.radians(float(txtDisplay.get())))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Sinh(self):
        try:
            self.result = False
            self.current = math.sinh(math.radians(float(txtDisplay.get())))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Cosh(self):
        try:
            self.result = False
            self.current = math.cosh(math.radians(float(txtDisplay.get())))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Tanh(self):
        try:
            self.result = False
            self.current = math.tanh(math.radians(float(txtDisplay.get())))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def ASin(self):
        try:
            self.result = False
            self.current = math.degrees(math.asin((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def ACos(self):
        try:
            self.result = False
            self.current = math.degrees(math.acos((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def ATan(self):
        try:
            self.result = False
            self.current = math.degrees(math.atan((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Pi(self):
        try:
            self.result = False
            self.current =math.pi
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Enumber(self):
        try:
            self.result = False
            self.current =math.e
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Tau(self):
        try:
            self.result = False
            self.current =math.tau
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def LN(self):
        try:
            self.result = False
            self.current =(math.log((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Log2(self):
        try:
            self.result = False
            self.current =(math.log2((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")
    def Log10(self):
        try:
            self.result = False
            self.current =(math.log10((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")

    def Log_1p(self):
        try:
            self.result = False
            self.current =(math.log1p((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")

    def Degree(self):
        try:
            self.result = False
            self.current =(math.degrees((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")

    def Fabs(self):
        try:
            self.result = False
            self.current = (math.fabs((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")

    def Mantisa(self):
        try:
            self.result = False
            self.current = (math.frexp((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")


    def Radius(self):
        try:
            self.result = False
            self.current =(math.radians((float(txtDisplay.get()))))
            self.display(self.current)
        except(Exception):
            self.display("Error!!")

def shotAbout():

    try:


        # playsound.playsound("info.mp3")
        talk("Welcome\n"
             "Please wait until I finish reading the instructions\n"
             "This calculator allows the user to switch from one view to another\n,namely,\nThe Standart mode and the Scientific mode\n"
             "This changes can be made on the file option on the menu\n"
             "The standart mode allows the user to use normal calculator operation ,\n and the scientific mode allows "
             "the user to use trignometric or statistical operations\n"
             "To use this calculator\n,first enter the number on the screen\nthen press the operation you want to perform\n"
             "That's all for now\n Thank you")



    except(Exception):
        talk("Failed")


#============================= WIDGETS ==========================
added_value=Calc()

txtDisplay = Entry(calc, font=('arial', 20, 'bold'), bg='khaki', bd=3, width=27
                       , justify=RIGHT)
text=Label(calc,text="Stats Calculator", font=('arial', 20, 'bold'))

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STANDARD VIEW %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def Standard_View():

    txtDisplay.grid(row=0, column=0, columnspan=4, pady=1)
    txtDisplay.insert(0, "")
    calc.grid()
    # ===============================================================================================
    numberpad = "789456123"
    i = 0
    btn = []
    for j in range(2, 5):
        for q in range(3):
            btn.append(Button(calc, width=6, height=2, font=('arial', 20, 'bold'),
                              bd=1, text=numberpad[i]))
            btn[i].grid(row=j, column=q, pady=1)
            btn[i]["command"] = lambda x=numberpad[i]: added_value.Number_Enter(x)
            i += 1
    # ==============================================================

    # ===============================ROW 1=============================''
    bdd = 1
    bgg = "khaki"
    btnCE = (Button(calc, width=6, height=2,
                    font=('arial', 20, 'bold'), bg=bgg
                    , bd=bdd, text="CE", command=added_value.Clear_All_Entry)).grid(row=1, column=0, pady=0)

    btnC = (Button(calc, width=6, height=2,
                   font=('arial', 20, 'bold'), bg=bgg
                   , bd=bdd, text="C", command=added_value.Clear_Entry)).grid(row=1, column=1, pady=1)

    btnSqRoot = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="√",
                        command=added_value.Sqaure_Root)).grid(row=1,
                                                               column=2, pady=1)

    # ===============================operators=====================================

    btnAdd = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text=chr(43)
                     , command=lambda: added_value.operation("add"))).grid(row=1, column=3, pady=1)

    btnSub = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text=chr(45)
                     , command=lambda: added_value.operation("sub"))).grid(row=2, column=3, pady=1)

    btnMulti = (Button(calc, width=6, height=2,
                       font=('arial', 20, 'bold'), bg=bgg
                       , bd=bdd, text="×"
                       , command=lambda: added_value.operation("multi"))).grid(row=3, column=3, pady=1)

    btnDiv = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text=chr(247)
                     , command=lambda: added_value.operation("divide"))).grid(row=4, column=3, pady=1)

    # ===============================ROW 5=====================================

    btn0 = (Button(calc, width=6, height=2,
                   font=('arial', 20, 'bold'), bg=bgg
                   , bd=bdd, text="0"

                   , command=lambda: added_value.Number_Enter(0))).grid(row=5, column=0, pady=1)

    btnDot = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text="."
                     , command=lambda: added_value.Number_Enter("."))).grid(row=5, column=1, pady=1)
    btnPM = (Button(calc, width=6, height=2,
                    font=('arial', 20, 'bold'), bg=bgg
                    , bd=bdd, text=chr(177), command=added_value.MathsPM)).grid(row=5, column=2, pady=1)

    btnEqual = (Button(calc, width=6, height=2,
                       font=('arial', 20, 'bold'), bg=bgg
                       , bd=bdd, text="=", command=added_value.sum_of_total)).grid(row=5, column=3, pady=1)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ SCIENTIFIC VIEW ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

def Scientific_View():
    text.grid(row=0, column=4, columnspan=4, pady=1)
    txtDisplay.grid(row=0, column=0, columnspan=4, pady=1)
    txtDisplay.insert(0, "")
    calc.grid()
    # ===============================================================================================
    numberpad = "789456123"
    i = 0
    btn = []
    for j in range(2, 5):
        for q in range(3):
            btn.append(Button(calc, width=6, height=2, font=('arial', 20, 'bold'),
                              bd=1, text=numberpad[i]))
            btn[i].grid(row=j, column=q, pady=1)
            btn[i]["command"] = lambda x=numberpad[i]: added_value.Number_Enter(x)
            i += 1
    # ==============================================================

    # ===============================ROW 1=============================''
    bdd = 1
    bgg = "khaki"
    btnCE = (Button(calc, width=6, height=2,
                    font=('arial', 20, 'bold'), bg=bgg
                    , bd=bdd, text="CE", command=added_value.Clear_All_Entry)).grid(row=1, column=0, pady=0)

    btnC = (Button(calc, width=6, height=2,
                   font=('arial', 20, 'bold'), bg=bgg
                   , bd=bdd, text="C", command=added_value.Clear_Entry)).grid(row=1, column=1, pady=1)

    btnSqRoot = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="√",
                        command=added_value.Sqaure_Root)).grid(row=1,
                                                               column=2, pady=1)
    btnPi = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="π",
                        command=added_value.Pi)).grid(row=1,
                                                               column=4, pady=1)

    btnE = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="e",
                        command=added_value.Enumber)).grid(row=1,
                                                               column=5, pady=1)

    btnTau = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="τ",
                        command=added_value.Tau)).grid(row=1,
                                                               column=6, pady=1)

    btnLN = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="ln",
                        command=added_value.LN)).grid(row=1,
                                                               column=7, pady=1)

    # ===============================ROW 2=============================''

    btnSin = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold')
                     , bd=bdd, text="sin",
                     command=added_value.Sin)).grid(row=2,
                                                    column=4, pady=1)

    btnCos = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold')
                     , bd=bdd, text="cos",
                     command=added_value.Cos)).grid(row=2,
                                                    column=5, pady=1)

    btnTan = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold')
                     , bd=bdd, text="tan",
                     command=added_value.Tan)).grid(row=2,
                                                    column=6, pady=1)
    btnLog2 = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text="log2",
                     command=added_value.Log2)).grid(row=2,
                                                            column=7, pady=1)

    # ===============================ROW 3=============================''
    btnSinh = (Button(calc, width=6, height=2,
                      font=('arial', 20, 'bold')
                      , bd=bdd, text="sinh",
                      command=added_value.Sinh)).grid(row=3,
                                                      column=4, pady=1)

    btnCosh = (Button(calc, width=6, height=2,
                      font=('arial', 20, 'bold')
                      , bd=bdd, text="cosh",
                      command=added_value.Cosh)).grid(row=3,
                                                      column=5, pady=1)

    btnTanh = (Button(calc, width=6, height=2,
                      font=('arial', 20, 'bold')
                      , bd=bdd, text="tanh",
                      command=added_value.Tanh)).grid(row=3,
                                                      column=6, pady=1)

    btnLog10 = (Button(calc, width=6, height=2,
                      font=('arial', 20, 'bold'), bg=bgg
                      , bd=bdd, text="log10",
                      command=added_value.Log10)).grid(row=3,
                                                             column=7, pady=1)

    # ===============================ROW 4=============================''


    btnASin = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold')
                        , bd=bdd, text="sin-1",
                        command=added_value.ASin)).grid(row=4,
                                                               column=4, pady=1)

    btnACos = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold')
                        , bd=bdd, text="cos-1",
                        command=added_value.ACos)).grid(row=4,
                                                               column=5, pady=1)

    btnATan = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold')
                        , bd=bdd, text="tan-1",
                        command=added_value.ATan)).grid(row=4,
                                                               column=6, pady=1)

    btnLog_1p = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="log1p",
                        command=added_value.Log_1p)).grid(row=4,
                                                               column=7, pady=1)

    # ===============================ROW 5=============================''


    btnRad = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="Rad",
                        command=added_value.Radius)).grid(row=5,
                                                               column=4, pady=1)

    btnDeg = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="Deg",
                        command=added_value.Degree)).grid(row=5,
                                                               column=5, pady=1)

    btnFabs = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="fabs()",
                        command=added_value.Fabs)).grid(row=5,
                                                               column=6, pady=1)

    btnFlexp = (Button(calc, width=6, height=2,
                        font=('arial', 20, 'bold'), bg=bgg
                        , bd=bdd, text="Mantis",
                        command=added_value.Mantisa)).grid(row=5,
                                                               column=7, pady=1)

    # ===============================operators=====================================

    btnAdd = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text=chr(43)
                     , command=lambda: added_value.operation("add"))).grid(row=1, column=3, pady=1)

    btnSub = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text=chr(45)
                     , command=lambda: added_value.operation("sub"))).grid(row=2, column=3, pady=1)

    btnMulti = (Button(calc, width=6, height=2,
                       font=('arial', 20, 'bold'), bg=bgg
                       , bd=bdd, text="×"
                       , command=lambda: added_value.operation("multi"))).grid(row=3, column=3, pady=1)

    btnDiv = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text=chr(247)
                     , command=lambda: added_value.operation("divide"))).grid(row=4, column=3, pady=1)

    # ===============================ROW 5=====================================

    btn0 = (Button(calc, width=6, height=2,
                   font=('arial', 20, 'bold'), bg=bgg
                   , bd=bdd, text="0"

                   , command=lambda: added_value.Number_Enter(0))).grid(row=5, column=0, pady=1)

    btnDot = (Button(calc, width=6, height=2,
                     font=('arial', 20, 'bold'), bg=bgg
                     , bd=bdd, text="."
                     , command=lambda: added_value.Number_Enter("."))).grid(row=5, column=1, pady=1)
    btnPM = (Button(calc, width=6, height=2,
                    font=('arial', 20, 'bold'), bg=bgg
                    , bd=bdd, text=chr(177), command=added_value.MathsPM)).grid(row=5, column=2, pady=1)

    btnEqual = (Button(calc, width=6, height=2,
                       font=('arial', 20, 'bold'), bg="green"
                       , bd=bdd, text="=", command=added_value.sum_of_total)).grid(row=5, column=3, pady=1)
#^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

#==================================== MENU ========================

def iExit():
    iExit=tkinter.messagebox.askyesno("Coding With Clifford","Do you want to leave?")
    if iExit>0:
        root.destroy()

def Scientific():
    windowWidth = root.winfo_reqwidth()
    windowHeight = root.winfo_reqheight()


    # Gets both half the screen width/height and window width/height
    positionRight = int(root.winfo_screenwidth() / 2 - windowWidth / 2)
    positionDown = int(root.winfo_screenheight() / 2 - windowHeight / 2)

    # Positions the window in the center of the page.
    root.geometry("+{}+{}".format(positionRight, positionDown))

    root.geometry("880x482")
    root.resizable(width=False,height=False)
    Scientific_View()

def Standard():
    windowWidth = root.winfo_reqwidth()
    windowHeight = root.winfo_reqheight()


    # Gets both half the screen width/height and window width/height
    positionRight = int(root.winfo_screenwidth() / 2 - windowWidth / 2)
    positionDown = int(root.winfo_screenheight() / 2 - windowHeight / 2)

    # Positions the window in the center of the page.
    root.geometry("+{}+{}".format(positionRight, positionDown))

    #root.geometry("900x568+0+0")
    root.geometry("440x482")
    root.resizable(width=False,height=False)
    Standard_View()

menubar=Menu(calc)

filemenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="File",menu=filemenu)
filemenu.add_command(label="Standard",command=Standard,activebackground="khaki")
filemenu.add_command(label="Scientific",command=Scientific,activebackground="khaki")
filemenu.add_separator()
filemenu.add_command(label="Exit",command=iExit,activebackground="red")




helpmenu=Menu(menubar,tearoff=0)
menubar.add_cascade(label="Help",menu=helpmenu)
helpmenu.add_command(label="Get Help",activebackground="khaki", command=lambda :shotAbout())

# menu options
root.geometry("215x200")
root.resizable(width=False,height=False)
Std_btn=Button(root, width=10, height=1,font=('arial', 20, 'bold'), bg="red",anchor=CENTER
                       , bd=5, text="Standard",command=lambda :Standard())
Scn_btn=Button(root, width=10, height=1,font=('arial', 20, 'bold'), bg="red",
               bd=5, text="Scientific",command=lambda :Scientific())


text.grid(row=4,column=5,columnspan=5)
Std_btn.grid(row=3,column=0,columnspan=5)
Scn_btn.grid(row=4,column=0)

root.configure(menu=menubar)

windowWidth = root.winfo_reqwidth()
windowHeight = root.winfo_reqheight()


# Gets both half the screen width/height and window width/height
positionRight = int(root.winfo_screenwidth() / 2 - windowWidth / 2)
positionDown = int(root.winfo_screenheight() / 2 - windowHeight / 2)

# Positions the window in the center of the page.
root.geometry("+{}+{}".format(positionRight, positionDown))

root.mainloop()